How to Contribute
===
We welcome community contributions! You can help by reporting bugs, fixing code, adding new features and/or better documentation.

We use the common fork, feature branch, pull request workflow.  If you would like to contribute to the project, fork the project, create a feature branch, make your changes and then issue a pull request.  See [Using pull requests](https://help.github.com/articles/using-pull-requests/)

