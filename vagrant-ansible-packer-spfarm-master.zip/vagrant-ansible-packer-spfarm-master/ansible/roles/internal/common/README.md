Common Role
=========

Only holds the list of dependencies that is required